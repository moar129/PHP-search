<?php 
// $_POST kan byttes ud med $_GET
// har man på index.php
require_once 'config.php';
if(isset($msg)){
	echo $msg;
}

function clean($string) {
   $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

   return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}


// Search All
if (isset($_POST['searchAll']) && $_POST['searchAll'] != '') {
	$searchAll = "LIKE '%". clean($_POST['searchAll']) . "%'";
}else{
	$searchAll = null;
}

//Search on things
if (isset($_POST['category']) && $_POST['category'] != '' ) {
	$category = '='. clean($_POST['category']);
}else{
	$category = "!= 'null'";
}

if (isset($_POST['model']) && $_POST['model'] != '') {
	$model = '='. clean($_POST['model']);
}else{
	$model = "!= 'null'";
}

if (isset($_POST['price']) && $_POST['price'] != '') {
	$price = '<='. $_POST['price'];
}else{
	$price = "!= 'null'";
}

if (isset($_POST['search']) && $_POST['search'] != '' ) {
	$search = "LIKE '%". $_POST['search'] . "%'";
}else{
	$search = "!= 'null'";
}


$searchInput = isset($_POST['search']) && $_POST['search'] != '' ? $_POST['search'] : '';
$priceInput = isset($_POST['price']) && $_POST['price'] != '' ? $_POST['price'] : '';
$categorySelect = isset($_POST['category']) && $_POST['category'] != '' ? $_POST['category'] : '';
$modelSelect = isset($_POST['model']) && $_POST['model'] != '' ? $_POST['model'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>my Search</title>
</head>
<body>
	<form method="post">
		<select name="category">
			<option value="">Vælg Kategori</option>
			<?php
				// et eksempel på et udtræk
			$sql = $db->prepare("SELECT * FROM `category`");
			$sql->execute();
			foreach ($sql as $row) {
				if($categorySelect == $row['id']){
					echo '<option selected value="'.$row['id'].'">'.$row['name'].'</option>';
				} else {
					echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
				}
			}
			?>
		</select>
		<select name="model">
			<option value="">Vælg Producent</option>
			<?php
				// et eksempel på et udtræk
			$sql = $db->prepare("SELECT * FROM `models`");
			$sql->execute();
				// $sql = "SELECT * FROM `models`";
				// $result = mysqli_query($conn, $sql);
			foreach ($sql as $row) {
				if($modelSelect == $row['id']){
					echo '<option selected value="'.$row['id'].'">'.$row['name'].'</option>';
				} else {
					echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
				}
			}
			?>
		</select>
		<label>price</label>
		<input type="number" name="price" value="<?= $priceInput ?>">
		<label>search keyword</label>
		<input type="text" name="search" value="<?= $searchInput ?>">
		<button type="submit">Søg</button>
	</form>
	<?php
	// database udtræk
	if($searchAll != null){
		// et eksempel på et udtræk
		$sth = "SELECT products.id,
		products.name,
		products.price,
		models.name AS modelName,
		category.name AS categoryName
		FROM `products`
		INNER JOIN category ON products.fkCategoryId = category.id
		INNER JOIN models ON products.fkModelId = models.id
		WHERE models.name $searchAll
		OR category.name $searchAll
		OR products.name $searchAll";
	} else{
		// et eksempel på et udtræk
		$sth = "SELECT products.id,
		products.name,
		products.price,
		models.name AS modelName,
		category.name AS categoryName
		FROM `products`
		INNER JOIN category ON products.fkCategoryId = category.id
		INNER JOIN models ON products.fkModelId = models.id
		WHERE models.id $model
		AND category.id $category
		AND products.price $price
		AND products.name $search";
	}
	// echo "<pre>"  . var_dump($option) . "</pre>";
	echo $sth;
	$sql = $db->prepare($sth);
	$sql->execute();

	echo "<br>";

	foreach ($sql as $row) {
		echo $row['name'];
		echo '<br>' . $row['price'];
	}
	?>
</body>
</html>