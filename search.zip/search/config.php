<?php
ob_start();
session_start();

$host = "localhost";
$user = "root";
$pass = "";
$database = "search";
$msg = '';

//hashing salt
// $options = [
//     'cost' => 12,
//     'salt' => mcrypt_create_iv(22, MCRYPT_DEV_URANDOM),
// ];

try {
    $db = new PDO("mysql:host=$host;dbname=$database", $user, $pass); // connection til database
    $db->query("SET NAMES utf8");// gøre så det bliver dansk skrift.

    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {

    $msg = "<p style='z-index:99999;'> du må ikke komme ind fejlen er: " . $e->getMessage() . "fil: " . $e->getFile() . "linje: " . $e->getLine() . "</p>";
    //print_r($e);
}
?>